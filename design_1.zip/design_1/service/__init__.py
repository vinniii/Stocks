
from design_1.service import RequestServer as baker, StockInterface as manager, CalculatorCommandLineInterface as cli
def drive():
    input_map = cli.get_cli_request()
    api_req = baker.bake(input_map)
    manager.serve_request(api_req)


if __name__ == '__main__':
    drive()