def bake(input_map):
    #Model the request
    return input_map
