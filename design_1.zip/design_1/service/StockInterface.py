class StockInterface:
    @staticmethod
    def dividendYield(stock, time, quantity, type, price):
        log.info("Received request")
        pass

    @staticmethod
    def ratio(self, stock, time, quantity, type, price):
        log.info("Received request")
        pass

    @staticmethod
    def transaction(self, stock, time, quantity, type, price):
        log.info("Received request")
        pass

    @staticmethod
    def vws(self, stock, time, quantity, type, price):
        log.info("Received request")
        pass

    @staticmethod
    def asi(self, stock, time, quantity, type, price):
        log.info("Received request")
        pass

stock_interface = StockInterface()
def serve_request(request):
    choice = request.get("choice")
    stock = request.get("stock")
    time = request.get("time")
    quantity = request.get("quantity")
    type = request.get("type")
    price = request.get("price")
    # based on req_type route the request
    if request.get("choice") == "1":
        return stock_interface.dividendYield(stock, time, quantity, type, price)
    if request.get("choice") == "2":
        return stock_interface.ratio(stock, time, quantity, type, price)
    if request.get("choice") == "3":
        return stock_interface.transaction(stock, time, quantity, type, price)
    if request.get("choice") == "4":
        return stock_interface.vws(stock, time, quantity, type, price)
    if request.get("choice") == "5":
        return stock_interface.asi(stock, time, quantity, type, price)
    