
import argparse
import queue
import threading
import record_trade
import stock_params

from datetime import datetime
# This is to get input
def get_args():
    parser = argparse.ArgumentParser(description='GCBE')
    parser.add_argument('-Choice', '-c', dest='Choice', required=False, nargs='+', help='Choice of functionality')
    parser.add_argument('-Dividend', '-d', dest='Div', required=False, nargs='+', help='Dividend Yield')
    parser.add_argument('-P/E', '-pe', dest='Ratio', required=False, nargs='+', help='P/E Ratio')
    parser.add_argument('-Transaction', '-t', dest='Transaction', required=False, nargs='?', const = 1, help='Transaction Details, Provide, Quantity[default 1],Type[Buy or Sell] and Price')
    parser.add_argument('-VolWtStock', '-v', dest='VWS', required=False,  nargs='?', const = 1, help='Volume Weighted Stock')
    parser.add_argument('-AllSharedIndex', '-asi', dest='AllSharedIndex', required=False, nargs='?', const = 1, help='All Shared Index')
    return parser.parse_args()

def get_cli_request():
    # take inputs from arguments and return as an ordered list
    # [req_type, field1, field2, field3, field4, field5, field6]
    # or convert as map
    map_dict = {"choice":"", "stock":"", "time":"", "quantity":"","type":"","price":""}
    args = get_args()
    if args.Div or args.Ratio:
        if args.Dive:
            map_dict["choice"] = 1
        else:
            map_dict["choice"] = 2
        map_dict["stock"] = args.Div[0]
        map_dict["price"] = args.Div[1]
    if args.Transaction:
        now = datetime.now()
        time_stamp = now.strftime("%d/%m/%Y%H/%M/%S")
        stock = input("Provide Stock")
        quantity = float(input("Provide Stock Quantity"))
        typeStock = input("Provide Stock Type, B for Buy, S for Sell")
        price = float(input("Provide Stock Price"))
        map_dict["choice"] = 3
        map_dict["stock"] = stock
        map_dict["time"] = time_stamp
        map_dict["quantity"] = quantity
        map_dict["type"] = type
        map_dict["price"] = price
    
    if args.VWS:
        map_dict["choice"] = 4
        map_dict["stock"] = args.Div[0]

    if args.AllSharedIndex:
        map_dict["choice"] = 5
    
    return map_dict


