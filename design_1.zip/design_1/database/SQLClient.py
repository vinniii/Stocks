class SQLClient:
    def __init__(self):
        pass

    def fetch_all_stocks_for_company_in_last_five_minutes(self, query_map):
        pass
